package model;

public class Customer {
	private String customer_id;
	private String first_name;
	private String last_name;
	private String address;
	private String email;
	private long phone_number;
	private String password;
								
}
